
public class InnerThreaded extends ThreadedFastener{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7024857369012457384L;

	// thread,  material, finish, price/unit, unit size
		public InnerThreaded(String di, String mat, String fin, double up, int us) throws IllegalFastener{
			super(di, mat, fin, up, us);
		}
	//do nothing in this class, just an extension
}

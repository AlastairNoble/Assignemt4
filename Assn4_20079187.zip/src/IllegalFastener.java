
public class IllegalFastener extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3292889047196973345L;

	public IllegalFastener(String message) {
		super(message);
	}
}
